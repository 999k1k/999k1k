const express = require('express');
const router = express.Router();

// Mock data storage
const users = [];
const bookings = [];

// Login handler
router.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    res.json({ success: true, userId: user.id });
  } else {
    res.status(401).json({ success: false, message: 'Invalid credentials' });
  }
});

// Register handler
router.post('/api/register', (req, res) => {
  const { email, password } = req.body;

  if (users.some(u => u.email === email)) {
    res.status(400).json({ success: false, message: 'Email already exists' });
  } else {
    const newUser = { id: Date.now().toString(), email, password };
    users.push(newUser);
    res.json({ success: true, userId: newUser.id });
  }
});

// Booking handler
router.post('/api/booking', (req, res) => {
  const { date, time, userId } = req.body;

  if (!users.some(u => u.id === userId)) {
    res.status(400).json({ success: false, message: 'Invalid user ID' });
  } else {
    const newBooking = { id: Date.now().toString(), date, time, userId };
    bookings.push(newBooking);
    res.json({ success: true, bookingId: newBooking.id });
  }
});

// Get bookings handler
router.get('/api/bookings', (req, res) => {
  const userId = req.query.userId;

  if (!userId) {
    res.status(400).json({ success: false, message: 'User ID is required' });
  } else {
    const userBookings = bookings.filter(b => b.userId === userId);
    res.json({ success: true, bookings: userBookings });
  }
});

module.exports = router;