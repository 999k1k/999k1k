# Backend

Generated stub for inpt-booking-app. Run with `node server/index.js` after wiring an Express server.